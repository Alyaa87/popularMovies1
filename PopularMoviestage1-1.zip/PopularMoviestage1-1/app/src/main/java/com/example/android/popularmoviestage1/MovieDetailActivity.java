package com.example.android.popularmoviestage1;

public class MovieDetailActivity {

}
