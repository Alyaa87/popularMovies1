package com.ibrahim.popularmovies_stage1.interfaces;

import com.ibrahim.popularmovies_stage1.model.Movies;

/**
 * Created by ibrahim on 03/05/18.
 */

public interface OnItemClickListener {
    void onItemClick(Movies item);
}